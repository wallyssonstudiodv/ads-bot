#!/bin/bash
echo "🚀 Iniciando WhatsApp Bot Panel..."
echo ""
echo "📱 Painel web será aberto em: http://localhost:3000"
echo "🛑 Pressione Ctrl+C para parar o bot"
echo ""
node server.js
