const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require("crypto");
global.crypto = crypto;
const cron = require('node-cron');
// QR Code terminal (opcional)
let qrcode;
try {
    qrcode = require('qrcode-terminal');
} catch (error) {
    console.log('qrcode-terminal não instalado. QR codes não serão exibidos no terminal.');
    qrcode = null;
}
const { 
    default: makeWASocket, 
    DisconnectReason, 
    useMultiFileAuthState,
    fetchLatestBaileysVersion 
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');

class WhatsAppBotPanel {
    constructor() {
        this.app = express();
        this.server = http.createServer(this.app);
        this.io = socketIo(this.server, {
            cors: {
                origin: "*",
                methods: ["GET", "POST"]
            }
        });
        
        this.sock = null;
        this.isConnected = false;
        this.qrCode = null;
        
        // Configuração de pastas
        this.dataPath = './panel_data';
        this.authPath = './auth_info';
        this.uploadsPath = './uploads';
        
        this.setupDirectories();
        this.initializeData();
        this.setupMiddlewares();
        this.setupRoutes();
        this.setupSocketHandlers();
        this.startCronJobs();
        
        this.startServer();
    }
    
    setupDirectories() {
        [this.dataPath, this.authPath, this.uploadsPath].forEach(dir => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });
    }
    
    initializeData() {
        this.files = {
            groups: path.join(this.dataPath, 'groups.json'),
            ads: path.join(this.dataPath, 'ads.json'),
            schedules: path.join(this.dataPath, 'schedules.json'),
            history: path.join(this.dataPath, 'history.json'),
            config: path.join(this.dataPath, 'config.json')
        };
        
        // Inicializar arquivos se não existirem
        Object.entries(this.files).forEach(([key, file]) => {
            if (!fs.existsSync(file)) {
                let defaultData = {};
                if (key === 'history') defaultData = [];
                if (key === 'config') defaultData = {
                    botActive: false,
                    timezone: 'America/Sao_Paulo'
                };
                fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
            }
        });
        
        this.loadAllData();
    }
    
    loadAllData() {
        try {
            this.groups = JSON.parse(fs.readFileSync(this.files.groups, 'utf8'));
            this.ads = JSON.parse(fs.readFileSync(this.files.ads, 'utf8'));
            this.schedules = JSON.parse(fs.readFileSync(this.files.schedules, 'utf8'));
            this.history = JSON.parse(fs.readFileSync(this.files.history, 'utf8'));
            this.config = JSON.parse(fs.readFileSync(this.files.config, 'utf8'));
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
        }
    }
    
    saveData(type) {
        try {
            const data = this[type];
            fs.writeFileSync(this.files[type], JSON.stringify(data, null, 2));
            this.io.emit('dataUpdated', { type, data });
        } catch (error) {
            console.error(`Erro ao salvar ${type}:`, error);
        }
    }
    
    setupMiddlewares() {
        this.app.use(cors());
        this.app.use(express.json({ limit: '50mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));
        this.app.use('/uploads', express.static(this.uploadsPath));
        this.app.use(express.static('public'));
        
        // Configurar multer para upload de imagens
        this.upload = multer({
            storage: multer.diskStorage({
                destination: (req, file, cb) => {
                    cb(null, this.uploadsPath);
                },
                filename: (req, file, cb) => {
                    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
                    const ext = path.extname(file.originalname);
                    cb(null, 'ad-' + uniqueSuffix + ext);
                }
            }),
            limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
            fileFilter: (req, file, cb) => {
                console.log('📁 Upload de arquivo:', file.originalname, 'Tipo:', file.mimetype);
                if (file.mimetype.startsWith('image/')) {
                    cb(null, true);
                } else {
                    cb(new Error('Apenas imagens são permitidas!'), false);
                }
            }
        });
    }
    
    setupRoutes() {
        // Rota principal - serve o painel
        this.app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, 'public', 'index.html'));
        });
        
        // API Routes
        
        // Status do bot
        this.app.get('/api/status', (req, res) => {
            res.json({
                connected: this.isConnected,
                qrCode: this.qrCode,
                config: this.config,
                connectionDetails: {
                    hasSocket: !!this.sock,
                    timestamp: new Date().toISOString()
                },
                stats: {
                    groups: Object.keys(this.groups).length,
                    ads: Object.keys(this.ads).length,
                    schedules: Object.keys(this.schedules).length,
                    history: this.history.length
                }
            });
        });
        
        // Conectar/Desconectar bot
        this.app.post('/api/connect', (req, res) => {
            if (!this.isConnected) {
                this.initializeWhatsApp();
                res.json({ message: 'Iniciando conexão...' });
            } else {
                res.json({ message: 'Bot já conectado' });
            }
        });
        
        this.app.post('/api/disconnect', (req, res) => {
            if (this.sock) {
                this.sock.end();
                this.isConnected = false;
                this.qrCode = null;
                res.json({ message: 'Bot desconectado' });
                this.io.emit('connectionStatus', { connected: false, qrCode: null });
            } else {
                res.json({ message: 'Bot não estava conectado' });
            }
        });
        
        // Refresh QR Code
        this.app.post('/api/refresh-qr', (req, res) => {
            if (!this.isConnected && this.sock) {
                // Fechar conexão atual e reiniciar
                this.sock.end();
                setTimeout(() => {
                    this.initializeWhatsApp();
                }, 1000);
                res.json({ message: 'Regenerando QR Code...' });
            } else if (this.isConnected) {
                res.json({ message: 'Bot já está conectado' });
            } else {
                res.json({ message: 'Iniciando nova conexão...' });
                this.initializeWhatsApp();
            }
        });
        
        // Grupos
        this.app.get('/api/groups', (req, res) => {
            res.json(this.groups);
        });
        
        this.app.post('/api/groups/refresh', async (req, res) => {
            if (this.sock && this.isConnected) {
                await this.loadGroups();
                res.json({ message: 'Lista de grupos atualizada', groups: this.groups });
            } else {
                res.status(400).json({ error: 'Bot não conectado' });
            }
        });
        
        this.app.post('/api/groups/:groupId/toggle', (req, res) => {
            const { groupId } = req.params;
            if (this.groups[groupId]) {
                this.groups[groupId].selected = !this.groups[groupId].selected;
                this.saveData('groups');
                res.json({ message: 'Status do grupo atualizado' });
            } else {
                res.status(404).json({ error: 'Grupo não encontrado' });
            }
        });
        
        // Anúncios
        this.app.get('/api/ads', (req, res) => {
            res.json(this.ads);
        });
        
        this.app.post('/api/ads', this.upload.single('image'), (req, res) => {
            try {
                const { type, title, content } = req.body;
                const adId = 'ad_' + Date.now();
                
                console.log('📝 Criando anúncio:', { type, title, hasFile: !!req.file });
                
                const newAd = {
                    id: adId,
                    type,
                    title,
                    content,
                    createdAt: new Date().toISOString(),
                    isActive: true
                };
                
                if (type === 'image' && req.file) {
                    // Salvar apenas o nome do arquivo, não o caminho completo
                    newAd.imagePath = `/uploads/${req.file.filename}`;
                    console.log('🖼️ Imagem salva:', newAd.imagePath);
                    console.log('📁 Arquivo físico:', req.file.path);
                }
                
                this.ads[adId] = newAd;
                this.saveData('ads');
                
                this.addToHistory('ad_created', `Anúncio criado: ${title}`, adId);
                
                res.json({ message: 'Anúncio criado com sucesso', ad: newAd });
            } catch (error) {
                console.error('❌ Erro ao criar anúncio:', error);
                res.status(500).json({ error: error.message });
            }
        });
        
        this.app.put('/api/ads/:adId', this.upload.single('image'), (req, res) => {
            const { adId } = req.params;
            if (!this.ads[adId]) {
                return res.status(404).json({ error: 'Anúncio não encontrado' });
            }
            
            try {
                const { type, title, content } = req.body;
                
                this.ads[adId] = {
                    ...this.ads[adId],
                    type,
                    title,
                    content,
                    updatedAt: new Date().toISOString()
                };
                
                if (type === 'image' && req.file) {
                    this.ads[adId].imagePath = `/uploads/${req.file.filename}`;
                }
                
                this.saveData('ads');
                this.addToHistory('ad_updated', `Anúncio atualizado: ${title}`, adId);
                
                res.json({ message: 'Anúncio atualizado com sucesso', ad: this.ads[adId] });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        
        this.app.delete('/api/ads/:adId', (req, res) => {
            const { adId } = req.params;
            if (this.ads[adId]) {
                const title = this.ads[adId].title;
                delete this.ads[adId];
                this.saveData('ads');
                this.addToHistory('ad_deleted', `Anúncio deletado: ${title}`, adId);
                res.json({ message: 'Anúncio deletado com sucesso' });
            } else {
                res.status(404).json({ error: 'Anúncio não encontrado' });
            }
        });
        
        this.app.post('/api/ads/:adId/toggle', (req, res) => {
            const { adId } = req.params;
            if (this.ads[adId]) {
                this.ads[adId].isActive = !this.ads[adId].isActive;
                this.saveData('ads');
                const status = this.ads[adId].isActive ? 'ativado' : 'desativado';
                this.addToHistory('ad_toggled', `Anúncio ${status}: ${this.ads[adId].title}`, adId);
                res.json({ message: `Anúncio ${status} com sucesso` });
            } else {
                res.status(404).json({ error: 'Anúncio não encontrado' });
            }
        });
        
        // Agendamentos
        this.app.get('/api/schedules', (req, res) => {
            res.json(this.schedules);
        });
        
        this.app.post('/api/schedules', (req, res) => {
            try {
                const { name, adId, days, time, isActive = true } = req.body;
                const scheduleId = 'schedule_' + Date.now();
                
                const newSchedule = {
                    id: scheduleId,
                    name,
                    adId,
                    days,
                    time,
                    isActive,
                    createdAt: new Date().toISOString(),
                    lastRun: null,
                    nextRun: this.calculateNextRun(days, time)
                };
                
                this.schedules[scheduleId] = newSchedule;
                this.saveData('schedules');
                this.addToHistory('schedule_created', `Agendamento criado: ${name}`, scheduleId);
                
                res.json({ message: 'Agendamento criado com sucesso', schedule: newSchedule });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        
        this.app.put('/api/schedules/:scheduleId', (req, res) => {
            const { scheduleId } = req.params;
            if (!this.schedules[scheduleId]) {
                return res.status(404).json({ error: 'Agendamento não encontrado' });
            }
            
            try {
                const { name, adId, days, time, isActive } = req.body;
                
                this.schedules[scheduleId] = {
                    ...this.schedules[scheduleId],
                    name,
                    adId,
                    days,
                    time,
                    isActive,
                    updatedAt: new Date().toISOString(),
                    nextRun: this.calculateNextRun(days, time)
                };
                
                this.saveData('schedules');
                this.addToHistory('schedule_updated', `Agendamento atualizado: ${name}`, scheduleId);
                
                res.json({ message: 'Agendamento atualizado com sucesso', schedule: this.schedules[scheduleId] });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        
        this.app.delete('/api/schedules/:scheduleId', (req, res) => {
            const { scheduleId } = req.params;
            if (this.schedules[scheduleId]) {
                const name = this.schedules[scheduleId].name;
                delete this.schedules[scheduleId];
                this.saveData('schedules');
                this.addToHistory('schedule_deleted', `Agendamento deletado: ${name}`, scheduleId);
                res.json({ message: 'Agendamento deletado com sucesso' });
            } else {
                res.status(404).json({ error: 'Agendamento não encontrado' });
            }
        });
        
        this.app.post('/api/schedules/:scheduleId/toggle', (req, res) => {
            const { scheduleId } = req.params;
            if (this.schedules[scheduleId]) {
                this.schedules[scheduleId].isActive = !this.schedules[scheduleId].isActive;
                this.saveData('schedules');
                const status = this.schedules[scheduleId].isActive ? 'ativado' : 'desativado';
                this.addToHistory('schedule_toggled', `Agendamento ${status}: ${this.schedules[scheduleId].name}`, scheduleId);
                res.json({ message: `Agendamento ${status} com sucesso` });
            } else {
                res.status(404).json({ error: 'Agendamento não encontrado' });
            }
        });
        
        // Envio manual
        this.app.post('/api/send-now', async (req, res) => {
            const { adId } = req.body;
            
            console.log('📤 Solicitação de envio manual para anúncio:', adId);
            
            if (!this.ads[adId]) {
                console.log('❌ Anúncio não encontrado:', adId);
                return res.status(404).json({ error: 'Anúncio não encontrado' });
            }
            
            if (!this.isConnected) {
                console.log('❌ Bot não conectado');
                return res.status(400).json({ error: 'Bot não conectado' });
            }
            
            const selectedGroups = Object.values(this.groups).filter(g => g.selected);
            if (selectedGroups.length === 0) {
                console.log('❌ Nenhum grupo selecionado');
                return res.status(400).json({ error: 'Nenhum grupo selecionado para envio' });
            }
            
            console.log(`📊 Enviando para ${selectedGroups.length} grupos selecionados`);
            
            try {
                const result = await this.sendAdToSelectedGroups(adId);
                this.addToHistory('manual_send', `Envio manual do anúncio: ${this.ads[adId].title}`, adId, result);
                
                console.log('✅ Envio manual concluído:', result);
                res.json({ 
                    message: `Envio concluído! ${result.success} sucessos, ${result.failed} falhas`, 
                    result 
                });
                
            } catch (error) {
                console.error('❌ Erro no envio manual:', error);
                res.status(500).json({ error: error.message });
            }
        });
        
        // Histórico
        this.app.get('/api/history', (req, res) => {
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 50;
            const startIndex = (page - 1) * limit;
            const endIndex = startIndex + limit;
            
            const paginatedHistory = this.history.slice().reverse().slice(startIndex, endIndex);
            
            res.json({
                history: paginatedHistory,
                pagination: {
                    page,
                    limit,
                    total: this.history.length,
                    totalPages: Math.ceil(this.history.length / limit)
                }
            });
        });
        
        this.app.delete('/api/history', (req, res) => {
            this.history = [];
            this.saveData('history');
            res.json({ message: 'Histórico limpo com sucesso' });
        });
        
        // Debug - listar arquivos de upload
        this.app.get('/api/debug/uploads', (req, res) => {
            try {
                const files = fs.readdirSync(this.uploadsPath);
                const fileList = files.map(filename => ({
                    filename,
                    path: path.join(this.uploadsPath, filename),
                    exists: fs.existsSync(path.join(this.uploadsPath, filename)),
                    size: fs.existsSync(path.join(this.uploadsPath, filename)) ? 
                        fs.statSync(path.join(this.uploadsPath, filename)).size : 0
                }));
                
                res.json({
                    uploadsPath: this.uploadsPath,
                    files: fileList,
                    ads: Object.values(this.ads).map(ad => ({
                        id: ad.id,
                        title: ad.title,
                        type: ad.type,
                        imagePath: ad.imagePath
                    }))
                });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        
        // Controles do sistema automatico
        this.app.get('/api/auto-send/status', (req, res) => {
            res.json({
                enabled: this.config.autoSendEnabled !== false, // default true
                nextHour: this.getNextHour(),
                activeAds: Object.values(this.ads).filter(ad => ad.isActive).length,
                selectedGroups: Object.values(this.groups).filter(g => g.selected).length
            });
        });

        this.app.post('/api/auto-send/toggle', (req, res) => {
            this.config.autoSendEnabled = !this.config.autoSendEnabled;
            this.saveData('config');
            
            const status = this.config.autoSendEnabled ? 'ativado' : 'desativado';
            this.addToHistory('auto_send_toggle', `Sistema automatico ${status}`);
            
            res.json({ 
                message: `Sistema automatico ${status}`,
                enabled: this.config.autoSendEnabled
            });
        });

        // Configurações ante banimento
        this.app.get('/api/anti-ban/config', (req, res) => {
            const antiBanConfig = {
                delayBetweenGroups: this.config.delayBetweenGroups || 30000,
                maxGroupsPerBatch: this.config.maxGroupsPerBatch || 5,
                batchDelay: this.config.batchDelay || 300000,
                randomizeDelay: this.config.randomizeDelay !== false
            };
            
            res.json(antiBanConfig);
        });

        this.app.post('/api/anti-ban/config', (req, res) => {
            try {
                const { delayBetweenGroups, maxGroupsPerBatch, batchDelay, randomizeDelay } = req.body;
                
                // Validações de segurança
                if (delayBetweenGroups < 5000) {
                    return res.status(400).json({ error: 'Delay entre grupos deve ser no mínimo 5 segundos' });
                }
                
                if (maxGroupsPerBatch > 10) {
                    return res.status(400).json({ error: 'Máximo 10 grupos por lote para segurança' });
                }
                
                if (batchDelay < 60000) {
                    return res.status(400).json({ error: 'Delay entre lotes deve ser no mínimo 1 minuto' });
                }
                
                this.config.delayBetweenGroups = parseInt(delayBetweenGroups);
                this.config.maxGroupsPerBatch = parseInt(maxGroupsPerBatch);
                this.config.batchDelay = parseInt(batchDelay);
                this.config.randomizeDelay = randomizeDelay;
                
                this.saveData('config');
                
                this.addToHistory('anti_ban_config', 'Configurações ante banimento atualizadas');
                
                res.json({ 
                    message: 'Configurações ante banimento atualizadas com sucesso',
                    config: {
                        delayBetweenGroups: this.config.delayBetweenGroups,
                        maxGroupsPerBatch: this.config.maxGroupsPerBatch,
                        batchDelay: this.config.batchDelay,
                        randomizeDelay: this.config.randomizeDelay
                    }
                });
                
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        this.app.post('/api/auto-send/fire-now', async (req, res) => {
            try {
                await this.sendRandomAd();
                res.json({ message: 'Anuncio aleatorio disparado com sucesso!' });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
        this.app.post('/api/test-schedule/:scheduleId', async (req, res) => {
            const { scheduleId } = req.params;
            
            if (!this.schedules[scheduleId]) {
                return res.status(404).json({ error: 'Agendamento não encontrado' });
            }
            
            if (!this.isConnected) {
                return res.status(400).json({ error: 'Bot não conectado' });
            }
            
            const schedule = this.schedules[scheduleId];
            
            try {
                console.log(`🧪 TESTE MANUAL do agendamento: ${schedule.name}`);
                
                if (!this.ads[schedule.adId]) {
                    throw new Error('Anúncio não encontrado');
                }
                
                const result = await this.sendAdToSelectedGroups(schedule.adId);
                
                this.addToHistory('manual_schedule_test', `Teste manual do agendamento: ${schedule.name}`, schedule.adId, result);
                
                res.json({ 
                    message: `Teste executado com sucesso!`, 
                    schedule: schedule.name,
                    result 
                });
                
            } catch (error) {
                console.error('❌ Erro no teste do agendamento:', error);
                res.status(500).json({ error: error.message });
            }
        });
        
        // Atualizar horário de agendamento rapidamente (para teste)
        this.app.post('/api/schedules/:scheduleId/update-time', (req, res) => {
            const { scheduleId } = req.params;
            const { time } = req.body;
            
            if (!this.schedules[scheduleId]) {
                return res.status(404).json({ error: 'Agendamento não encontrado' });
            }
            
            // Validar formato do horário
            const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
            if (!timeRegex.test(time)) {
                return res.status(400).json({ error: 'Formato de horário inválido (use HH:MM)' });
            }
            
            const schedule = this.schedules[scheduleId];
            const oldTime = schedule.time;
            
            // Resetar chave de execução para permitir nova execução
            schedule.time = time;
            schedule.lastExecutionKey = '';
            schedule.updatedAt = new Date().toISOString();
            
            this.schedules[scheduleId] = schedule;
            this.saveData('schedules');
            
            console.log(`🕐 Horário do agendamento "${schedule.name}" alterado de ${oldTime} para ${time}`);
            this.addToHistory('schedule_time_updated', `Horário alterado: ${schedule.name} (${oldTime} → ${time})`, scheduleId);
            
            res.json({ 
                message: `Horário alterado com sucesso de ${oldTime} para ${time}`,
                schedule: schedule
            });
        });
        this.app.post('/api/check-schedules-now', async (req, res) => {
            try {
                console.log('🔄 Verificação manual de agendamentos solicitada');
                await this.checkSchedules();
                res.json({ message: 'Verificação de agendamentos executada' });
            } catch (error) {
                console.error('❌ Erro na verificação manual:', error);
                res.status(500).json({ error: error.message });
            }
        });
        this.app.get('/api/debug/status', (req, res) => {
            res.json({
                isConnected: this.isConnected,
                hasSocket: !!this.sock,
                selectedGroups: Object.values(this.groups).filter(g => g.selected).map(g => ({
                    id: g.id,
                    name: g.name
                })),
                activeAds: Object.values(this.ads).filter(ad => ad.isActive).length,
                activeSchedules: Object.values(this.schedules).filter(s => s.isActive).length,
                currentTime: new Date().toISOString()
            });
        });
        this.app.get('/api/config', (req, res) => {
            res.json(this.config);
        });
        
        this.app.put('/api/config', (req, res) => {
            this.config = { ...this.config, ...req.body };
            this.saveData('config');
            res.json({ message: 'Configurações atualizadas com sucesso', config: this.config });
        });
    }
    
    setupSocketHandlers() {
        this.io.on('connection', (socket) => {
            console.log('Cliente conectado ao painel:', socket.id);
            
            // Enviar status inicial
            socket.emit('connectionStatus', {
                connected: this.isConnected,
                qrCode: this.qrCode,
                status: this.isConnected ? 'Conectado' : 'Desconectado'
            });
            
            socket.on('disconnect', () => {
                console.log('Cliente desconectado do painel:', socket.id);
            });
        });
    }
    
    async initializeWhatsApp() {
        try {
            // Limpar estado anterior
            this.qrCode = null;
            this.isConnected = false;
            
            console.log('Inicializando conexão WhatsApp...');
            
            const { state, saveCreds } = await useMultiFileAuthState(this.authPath);
            const { version } = await fetchLatestBaileysVersion();
            
            this.sock = makeWASocket({
                version,
                logger: pino({ level: 'silent' }),
                printQRInTerminal: true,
                auth: state,
                generateHighQualityLinkPreview: true,
                browser: ['WhatsApp Bot Panel', 'Chrome', '1.0.0'],
                markOnlineOnConnect: false,
                defaultQueryTimeoutMs: 60000,
                connectTimeoutMs: 60000,
                keepAliveIntervalMs: 10000,
                emitOwnEvents: true
            });
            
            this.sock.ev.on('creds.update', saveCreds);
            this.sock.ev.on('connection.update', this.handleConnection.bind(this));
            this.sock.ev.on('groups.upsert', this.handleGroupsUpdate.bind(this));
            
            // Emitir status inicial
            this.io.emit('connectionStatus', { 
                connected: false, 
                qrCode: null,
                status: 'Iniciando conexão...' 
            });
            
        } catch (error) {
            console.error('Erro ao inicializar WhatsApp:', error);
            this.addToHistory('error', `Erro ao conectar: ${error.message}`);
            
            // Emitir erro para o frontend
            this.io.emit('connectionStatus', { 
                connected: false, 
                qrCode: null,
                error: error.message,
                status: 'Erro na conexão'
            });
        }
    }
    
    handleConnection(update) {
        const { connection, lastDisconnect, qr } = update;
        
        console.log('Connection update:', { 
            connection, 
            qr: !!qr, 
            lastDisconnect: lastDisconnect?.error?.message || 'none'
        });
        
        if (qr) {
            this.qrCode = qr;
            console.log('✅ QR Code gerado e enviado para o frontend');
            
            // Mostrar QR no terminal para debug (se disponível)
            if (qrcode) {
                qrcode.generate(qr, {small: true});
            }
            
            // Emitir QR Code para o frontend
            this.io.emit('connectionStatus', { 
                connected: false, 
                qrCode: qr,
                status: 'QR Code gerado - Escaneie com seu WhatsApp' 
            });
        }
        
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom)?.output?.statusCode !== DisconnectReason.loggedOut;
            
            console.log('❌ Conexão fechada:', lastDisconnect?.error?.message || 'Motivo desconhecido');
            this.addToHistory('disconnection', `Conexão perdida: ${lastDisconnect?.error?.message || 'Motivo desconhecido'}`);
            
            this.isConnected = false;
            this.qrCode = null;
            
            this.io.emit('connectionStatus', { 
                connected: false, 
                qrCode: null,
                status: shouldReconnect ? 'Tentando reconectar...' : 'Desconectado'
            });
            
            if (shouldReconnect) {
                console.log('🔄 Tentando reconectar em 5 segundos...');
                setTimeout(() => this.initializeWhatsApp(), 5000);
            }
            
        } else if (connection === 'open') {
            console.log('✅ Bot conectado ao WhatsApp!');
            this.isConnected = true;
            this.qrCode = null;
            
            this.io.emit('connectionStatus', { 
                connected: true, 
                qrCode: null,
                status: 'Conectado com sucesso!'
            });
            
            this.addToHistory('connection', 'Bot conectado com sucesso');
            
            // Carregar grupos automaticamente
            setTimeout(() => this.loadGroups(), 2000);
            
        } else if (connection === 'connecting') {
            console.log('🔄 Conectando ao WhatsApp...');
            this.io.emit('connectionStatus', { 
                connected: false, 
                qrCode: this.qrCode,
                status: 'Conectando...' 
            });
        }
    }
    
    handleGroupsUpdate(groups) {
        console.log('📱 Grupos atualizados:', groups.length);
        this.loadGroups();
    }
    
    async loadGroups() {
        if (!this.sock || !this.isConnected) return;
        
        try {
            console.log('📋 Carregando lista de grupos...');
            const groups = await this.sock.groupFetchAllParticipating();
            
            Object.values(groups).forEach(group => {
                const groupId = group.id;
                
                // Manter status de seleção se já existir
                const existingSelected = this.groups[groupId]?.selected || false;
                
                this.groups[groupId] = {
                    id: groupId,
                    name: group.subject,
                    participants: group.participants.length,
                    description: group.desc || '',
                    selected: existingSelected,
                    lastUpdated: new Date().toISOString()
                };
            });
            
            this.saveData('groups');
            this.addToHistory('groups_updated', `${Object.keys(groups).length} grupos carregados`);
            console.log(`✅ ${Object.keys(groups).length} grupos carregados`);
            
        } catch (error) {
            console.error('❌ Erro ao carregar grupos:', error);
            this.addToHistory('error', `Erro ao carregar grupos: ${error.message}`);
        }
    }
    
    async sendAdToSelectedGroups(adId) {
        const ad = this.ads[adId];
        if (!ad || !ad.isActive) {
            throw new Error('Anúncio não encontrado ou inativo');
        }
        
        const selectedGroups = Object.values(this.groups).filter(g => g.selected);
        if (selectedGroups.length === 0) {
            throw new Error('Nenhum grupo selecionado');
        }
        
        console.log(`📤 Enviando anúncio "${ad.title}" para ${selectedGroups.length} grupos...`);
        console.log(`🔍 Tipo do anúncio: ${ad.type}`);
        if (ad.type === 'image') {
            console.log(`🖼️ Caminho da imagem: ${ad.imagePath}`);
        }
        
        const results = {
            success: 0,
            failed: 0,
            errors: []
        };

        // Sistema ante banimento - configurações de segurança
        const antiBanConfig = {
            delayBetweenGroups: this.config.delayBetweenGroups || 30000, // 30 segundos entre grupos
            maxGroupsPerBatch: this.config.maxGroupsPerBatch || 5, // Máximo 5 grupos por vez
            batchDelay: this.config.batchDelay || 300000, // 5 minutos entre lotes
            randomizeDelay: this.config.randomizeDelay !== false // Randomizar delays
        };

        console.log(`🛡️ Sistema Ante Banimento Ativo:`);
        console.log(`   ⏱️ Delay entre grupos: ${antiBanConfig.delayBetweenGroups/1000}s`);
        console.log(`   📦 Grupos por lote: ${antiBanConfig.maxGroupsPerBatch}`);
        console.log(`   ⏳ Delay entre lotes: ${antiBanConfig.batchDelay/1000}s`);
        
        // Dividir grupos em lotes menores
        const batches = [];
        for (let i = 0; i < selectedGroups.length; i += antiBanConfig.maxGroupsPerBatch) {
            batches.push(selectedGroups.slice(i, i + antiBanConfig.maxGroupsPerBatch));
        }

        console.log(`📊 ${selectedGroups.length} grupos divididos em ${batches.length} lotes`);

        for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
            const batch = batches[batchIndex];
            
            console.log(`\n📦 Processando lote ${batchIndex + 1}/${batches.length} (${batch.length} grupos)`);

            for (let i = 0; i < batch.length; i++) {
                const group = batch[i];
                
                try {
                    console.log(`📬 [${results.success + results.failed + 1}/${selectedGroups.length}] Enviando para: ${group.name}`);
                    
                    if (ad.type === 'text') {
                        await this.sock.sendMessage(group.id, { text: ad.content });
                        console.log(`✅ Texto enviado para: ${group.name}`);
                        
                    } else if (ad.type === 'image' && ad.imagePath) {
                        // Corrigir caminho da imagem
                        let imagePath;
                        if (ad.imagePath.startsWith('/uploads/')) {
                            imagePath = path.join(__dirname, 'uploads', path.basename(ad.imagePath));
                        } else {
                            imagePath = path.join(__dirname, ad.imagePath);
                        }
                        
                        if (fs.existsSync(imagePath)) {
                            const imageBuffer = fs.readFileSync(imagePath);
                            
                            await this.sock.sendMessage(group.id, {
                                image: imageBuffer,
                                caption: ad.content || '',
                                jpegThumbnail: null
                            });
                            console.log(`✅ Imagem enviada para: ${group.name}`);
                            
                        } else {
                            throw new Error(`Imagem não encontrada: ${imagePath}`);
                        }
                    }
                    
                    results.success++;
                    
                    // Delay entre grupos no mesmo lote
                    if (i < batch.length - 1) {
                        let delay = antiBanConfig.delayBetweenGroups;
                        
                        // Randomizar delay para parecer mais humano
                        if (antiBanConfig.randomizeDelay) {
                            const variation = delay * 0.3; // ±30% de variação
                            delay = delay + (Math.random() * variation * 2 - variation);
                        }
                        
                        console.log(`⏱️ Aguardando ${Math.round(delay/1000)}s antes do próximo grupo...`);
                        await new Promise(resolve => setTimeout(resolve, delay));
                    }
                    
                } catch (error) {
                    console.error(`❌ Erro ao enviar para grupo ${group.name}:`, error);
                    results.failed++;
                    results.errors.push({
                        group: group.name,
                        error: error.message
                    });
                    
                    // Delay mesmo com erro
                    if (i < batch.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 5000));
                    }
                }
            }

            // Delay entre lotes (exceto no último lote)
            if (batchIndex < batches.length - 1) {
                let batchDelay = antiBanConfig.batchDelay;
                
                if (antiBanConfig.randomizeDelay) {
                    const variation = batchDelay * 0.2; // ±20% de variação
                    batchDelay = batchDelay + (Math.random() * variation * 2 - variation);
                }
                
                console.log(`⏳ Pausa entre lotes: ${Math.round(batchDelay/1000)}s...`);
                await new Promise(resolve => setTimeout(resolve, batchDelay));
            }
        }
        
        console.log(`📊 Envio concluído: ${results.success} sucessos, ${results.failed} falhas`);
        if (results.errors.length > 0) {
            console.log('❌ Erros encontrados:', results.errors);
        }
        
        return results;
    }
    
    calculateNextRun(days, time) {
        const [hour, minute] = time.split(':').map(Number);
        const now = new Date();
        const today = now.getDay(); // 0 = domingo
        
        // Converter dias da semana
        const dayMap = {
            'sunday': 0, 'monday': 1, 'tuesday': 2, 'wednesday': 3,
            'thursday': 4, 'friday': 5, 'saturday': 6
        };
        
        const targetDays = days.map(day => dayMap[day]).sort((a, b) => a - b);
        
        for (let i = 0; i < 7; i++) {
            const checkDate = new Date(now);
            checkDate.setDate(now.getDate() + i);
            checkDate.setHours(hour, minute, 0, 0);
            
            const checkDay = checkDate.getDay();
            
            if (targetDays.includes(checkDay) && checkDate > now) {
                return checkDate.toISOString();
            }
        }
        
        return null;
    }
    
    startCronJobs() {
        // Disparar anuncio automatico a cada hora (minuto 0 de cada hora)
        cron.schedule('0 * * * *', async () => {
            try {
                await this.sendRandomAd();
            } catch (error) {
                console.error('Erro no disparo automatico:', error);
                this.addToHistory('error', `Erro no disparo automatico: ${error.message}`);
            }
        });
        
        console.log('Sistema de disparo automatico iniciado - A cada hora no minuto 0');
    }

    async sendRandomAd() {
        if (!this.isConnected || !this.sock) {
            console.log('Bot desconectado - disparo cancelado');
            return;
        }

        // Verificar se o sistema automatico esta ativo
        if (this.config.autoSendEnabled === false) {
            console.log('Sistema automatico desativado');
            return;
        }

        // Obter anuncios ativos
        const activeAds = Object.values(this.ads).filter(ad => ad.isActive);
        if (activeAds.length === 0) {
            console.log('Nenhum anuncio ativo para disparar');
            return;
        }

        // Obter grupos selecionados
        const selectedGroups = Object.values(this.groups).filter(g => g.selected);
        if (selectedGroups.length === 0) {
            console.log('Nenhum grupo selecionado para disparo');
            return;
        }

        // Selecionar anuncio aleatorio
        const randomAd = activeAds[Math.floor(Math.random() * activeAds.length)];
        
        console.log(`\n=== DISPARO AUTOMATICO ===`);
        console.log(`Anuncio selecionado: ${randomAd.title}`);
        console.log(`Grupos selecionados: ${selectedGroups.length}`);
        
        try {
            const result = await this.sendAdToSelectedGroups(randomAd.id);
            
            const message = `Disparo automatico executado: ${randomAd.title} (${result.success} sucessos, ${result.failed} falhas)`;
            console.log(`SUCESSO: ${message}`);
            
            this.addToHistory('auto_send', message, randomAd.id, result);
            this.io.emit('autoSendExecuted', { 
                ad: randomAd, 
                result: result, 
                timestamp: new Date().toISOString() 
            });

        } catch (error) {
            console.error(`ERRO no disparo automatico:`, error.message);
            this.addToHistory('error', `Erro no disparo automatico: ${error.message}`, randomAd.id);
            this.io.emit('autoSendError', { 
                ad: randomAd, 
                error: error.message, 
                timestamp: new Date().toISOString() 
            });
        }
    }

    getNextHour() {
        const now = new Date();
        const nextHour = new Date(now);
        nextHour.setHours(now.getHours() + 1, 0, 0, 0);
        return nextHour.toLocaleString();
    }

    async sendToSelectedGroups(ad, selectedGroups) {
        const results = {
            success: 0,
            failed: 0,
            errors: []
        };

        console.log(`Iniciando envio do anuncio: ${ad.title}`);

        for (let i = 0; i < selectedGroups.length; i++) {
            const group = selectedGroups[i];
            
            try {
                console.log(`[${i + 1}/${selectedGroups.length}] Enviando para: ${group.name}`);

                if (ad.type === 'text') {
                    await this.sock.sendMessage(group.id, { text: ad.content });
                } else if (ad.type === 'image' && ad.imagePath) {
                    let imagePath;
                    if (ad.imagePath.startsWith('/uploads/')) {
                        imagePath = path.join(__dirname, 'uploads', path.basename(ad.imagePath));
                    } else {
                        imagePath = path.join(__dirname, ad.imagePath);
                    }

                    if (fs.existsSync(imagePath)) {
                        const imageBuffer = fs.readFileSync(imagePath);
                        await this.sock.sendMessage(group.id, {
                            image: imageBuffer,
                            caption: ad.content || '',
                            jpegThumbnail: null
                        });
                    } else {
                        throw new Error('Imagem nao encontrada');
                    }
                }

                results.success++;
                console.log(`Enviado com sucesso para: ${group.name}`);

                // Intervalo entre envios
                await new Promise(resolve => setTimeout(resolve, 2000));

            } catch (error) {
                console.error(`Erro ao enviar para ${group.name}:`, error.message);
                results.failed++;
                results.errors.push({
                    group: group.name,
                    error: error.message
                });

                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }

        console.log(`Envio concluido: ${results.success} sucessos, ${results.failed} falhas`);
        return results;
    }
    
    async checkSchedules() {
        if (!this.isConnected || !this.sock) {
            console.log('⏰ Agendamentos pausados - bot desconectado');
            return;
        }
        
        const now = new Date();
        const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        const currentDay = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][now.getDay()];
        
        // NOVO LOG FORMAT - se você ver este log, está usando a versão correta
        console.log(`\n🔥 NOVO SISTEMA - [${now.toLocaleString()}] Verificando agendamentos`);
        console.log(`⏰ Horário atual: ${currentTime}`);
        console.log(`📅 Dia atual: ${currentDay}`);
        
        const activeSchedules = Object.values(this.schedules).filter(s => s.isActive);
        console.log(`📋 Total de agendamentos ativos: ${activeSchedules.length}`);
        
        if (activeSchedules.length === 0) {
            console.log('❌ Nenhum agendamento ativo encontrado');
            return;
        }
        
        for (let i = 0; i < activeSchedules.length; i++) {
            const schedule = activeSchedules[i];
            
            console.log(`\n📋 [${i+1}/${activeSchedules.length}] Verificando: "${schedule.name}"`);
            console.log(`   🆔 ID: ${schedule.id}`);
            console.log(`   ⏰ Horário agendado: ${schedule.time}`);
            console.log(`   📅 Dias agendados: [${schedule.days.join(', ')}]`);
            console.log(`   📢 Anúncio ID: ${schedule.adId}`);
            console.log(`   📝 Anúncio existe: ${this.ads[schedule.adId] ? 'SIM' : 'NÃO'}`);
            
            if (this.ads[schedule.adId]) {
                console.log(`   📝 Nome do anúncio: "${this.ads[schedule.adId].title}"`);
                console.log(`   ✅ Anúncio ativo: ${this.ads[schedule.adId].isActive ? 'SIM' : 'NÃO'}`);
            }
            
            // Verificar se é o dia correto
            const isDayMatch = schedule.days.includes(currentDay);
            console.log(`   📅 Dia correto: ${isDayMatch} (${currentDay} está em [${schedule.days.join(', ')}]?)`);
            
            // Verificar se é o horário correto
            const isTimeMatch = schedule.time === currentTime;
            console.log(`   ⏰ Horário correto: ${isTimeMatch} (${schedule.time} === ${currentTime}?)`);
            
            if (isDayMatch && isTimeMatch) {
                // Criar chave única para este agendamento no dia/hora atual
                const executionKey = `${schedule.id}_${now.getFullYear()}_${(now.getMonth()+1).toString().padStart(2,'0')}_${now.getDate().toString().padStart(2,'0')}_${now.getHours().toString().padStart(2,'0')}_${now.getMinutes().toString().padStart(2,'0')}`;
                const lastExecutionKey = schedule.lastExecutionKey || '';
                
                console.log(`   🔑 Chave atual: ${executionKey}`);
                console.log(`   🔑 Última chave: ${lastExecutionKey}`);
                console.log(`   🔄 Já executado: ${executionKey === lastExecutionKey ? 'SIM' : 'NÃO'}`);
                
                if (executionKey !== lastExecutionKey) {
                    console.log(`\n🚀🚀🚀 EXECUTANDO AGENDAMENTO: "${schedule.name}" 🚀🚀🚀`);
                    
                    try {
                        // Verificar se o anúncio ainda existe e está ativo
                        if (!this.ads[schedule.adId]) {
                            throw new Error('Anúncio não encontrado - pode ter sido deletado');
                        }
                        
                        if (!this.ads[schedule.adId].isActive) {
                            throw new Error('Anúncio está desativado');
                        }
                        
                        // Verificar se há grupos selecionados
                        const selectedGroups = Object.values(this.groups).filter(g => g.selected);
                        console.log(`   📱 Grupos selecionados: ${selectedGroups.length}`);
                        
                        if (selectedGroups.length === 0) {
                            throw new Error('Nenhum grupo selecionado para envio');
                        }
                        
                        selectedGroups.forEach(group => {
                            console.log(`   📱 Grupo: ${group.name} (${group.id})`);
                        });
                        
                        console.log(`   📤 Iniciando envio...`);
                        const result = await this.sendAdToSelectedGroups(schedule.adId);
                        
                        // Atualizar dados do agendamento
                        schedule.lastRun = now.toISOString();
                        schedule.lastExecutionKey = executionKey;
                        schedule.executionCount = (schedule.executionCount || 0) + 1;
                        
                        // Salvar mudanças
                        this.schedules[schedule.id] = schedule;
                        this.saveData('schedules');
                        
                        const message = `Agendamento executado: ${schedule.name} - ${result.success} sucessos, ${result.failed} falhas`;
                        this.addToHistory('scheduled_send', message, schedule.adId, result);
                        
                        console.log(`✅✅✅ SUCESSO: ${message}`);
                        
                        // Emitir evento para o frontend
                        this.io.emit('scheduleExecuted', {
                            schedule: schedule,
                            result: result,
                            timestamp: now.toISOString()
                        });
                        
                    } catch (error) {
                        console.error(`❌❌❌ ERRO no agendamento "${schedule.name}":`, error.message);
                        
                        // Salvar erro no agendamento
                        schedule.lastError = {
                            message: error.message,
                            timestamp: now.toISOString()
                        };
                        schedule.lastExecutionKey = executionKey; // Marcar como tentado mesmo com erro
                        
                        this.schedules[schedule.id] = schedule;
                        this.saveData('schedules');
                        
                        this.addToHistory('error', `Erro no agendamento ${schedule.name}: ${error.message}`, schedule.id);
                        
                        // Emitir erro para o frontend
                        this.io.emit('scheduleError', {
                            schedule: schedule,
                            error: error.message,
                            timestamp: now.toISOString()
                        });
                    }
                } else {
                    console.log(`   ⏭️ Já executado neste horário hoje`);
                }
            } else {
                const reason = !isDayMatch ? 'dia incorreto' : 'horário incorreto';
                console.log(`   ⏭️ Não é o momento (${reason})`);
            }
        }
        
        console.log(`\n⏰ Verificação de agendamentos concluída\n`);
    }
    
    addToHistory(type, message, relatedId = null, data = null) {
        const entry = {
            id: 'hist_' + Date.now(),
            type,
            message,
            relatedId,
            data,
            timestamp: new Date().toISOString()
        };
        
        this.history.push(entry);
        
        // Manter apenas os últimos 5000 registros
        if (this.history.length > 5000) {
            this.history = this.history.slice(-5000);
        }
        
        this.saveData('history');
        this.io.emit('newHistoryEntry', entry);
    }
    
    startServer() {
        const PORT = process.env.PORT || 8080;
        this.server.listen(PORT, () => {
            console.log('\n' + '='.repeat(50));
            console.log('🚀 PAINEL WHATSAPP BOT INICIADO COM SUCESSO!');
            console.log('='.repeat(50));
            console.log(`📡 Servidor rodando em: http://localhost:${PORT}`);
            console.log(`📱 Acesse o painel web para gerenciar o bot`);
            console.log(`📋 Logs do sistema serão exibidos aqui`);
            console.log('='.repeat(50) + '\n');
            
            // Log de inicialização
            this.addToHistory('system_start', 'Sistema iniciado com sucesso');
        });
    }
}

// Inicializar o sistema
const botPanel = new WhatsAppBotPanel();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n⏹️  Encerrando sistema...');
    if (botPanel.sock) {
        botPanel.sock.end();
    }
    botPanel.addToHistory('system_shutdown', 'Sistema encerrado');
    setTimeout(() => {
        console.log('✅ Sistema encerrado com sucesso!');
        process.exit(0);
    }, 2000);
});

// Capturar erros não tratados
process.on('uncaughtException', (error) => {
    console.error('❌ Erro não tratado:', error);
    if (botPanel) {
        botPanel.addToHistory('error', `Erro não tratado: ${error.message}`);
    }
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Promise rejeitada:', reason);
    if (botPanel) {
        botPanel.addToHistory('error', `Promise rejeitada: ${reason}`);
    }
});

module.exports = WhatsAppBotPanel;
